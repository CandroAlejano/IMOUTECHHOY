import java.io.*;

import java.util.Scanner;
public class Problema {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        BufferedReader br = null;
        BufferedWriter bw = null;

        try {
            br = new BufferedReader(new FileReader("mensaje.txt"));
            bw = new BufferedWriter(new FileWriter("mensaje_cifrado.txt"));

            String linea = null;

            /* Lectura y validación  de clave */

            System.out.print("Introduce el texto a encriptar: ");

            String texto = sc.nextLine();

            System.out.print("Introduce la clave: ");

            String clave = sc.nextLine();

            int[] numClave = new int[clave.length()];

            for (int i = 0; i < clave.length(); i++) {
                char c = clave.charAt(i);
                numClave[i] = Character.toUpperCase(c) - 'A';
            }

            StringBuilder sb = null;

            while ((linea = br.readLine()) != null) {
                sb = new StringBuilder(linea.length());


                /* Aquí vendría la lógica del programa */
                int j = 0;

                for (int i = 0; i < texto.length(); i++) {
                    char c = texto.charAt(i);
                    if(Character.isLetter(c)) {
                        int numero = (Character.toUpperCase(c) - 'A' + numClave[j]) % 26;
                        sb.append((char) ('A' + numero));
                        j = (j + 1) % clave.length();
                    } else {
                        sb.append(c);
                    }
                }
            }
            bw.write(sb.toString()); /* Escribe la cadena de caracteres en el fichero*/
            bw.newLine(); /* escribe nueva línea en el fichero */
            System.out.println("El texto cifrado es: " + sb.toString());
            System.out.println("El mensaje ha sido cifrado correctamente");

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null)
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            if (bw != null)
                try {
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }

    }

}
